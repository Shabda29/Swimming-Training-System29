-- Create database
CREATE DATABASE pool_booking;

-- Use the database
USE pool_booking;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, role) VALUES
('admin', '$2y$10$S4CwI7P6u8d7p6K4jGx6P.BXQ7ZZR7tR6upzZ/jbX1H1oN6WB7z2G', 'admin');

-- Create bookings table (with coach column)
CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  date DATE NOT NULL,
  slot_time VARCHAR(50) NOT NULL,
  coach VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Optional sample data
INSERT INTO bookings (name, phone, date, slot_time, coach) VALUES
('Ramesh Shrestha', '9812345678', '2025-11-10', '7AM - 8AM', 'Coach Sita'),
('Bikash Lama', '9801234567', '2025-11-11', '5PM - 6PM', 'Coach Prakash');
